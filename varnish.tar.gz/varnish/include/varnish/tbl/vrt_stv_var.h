/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit and run generate.py instead.
 */
VRTSTVVAR(free_space,	BYTES,	long long,	0.)
VRTSTVVAR(used_space,	BYTES,	long long,	0.)
VRTSTVVAR(happy,	BOOL,	unsigned,	0)
