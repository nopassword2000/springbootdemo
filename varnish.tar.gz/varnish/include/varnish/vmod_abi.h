#define VMOD_ABI_Version "Varnish 5.0.0 99d036f"
