.. include:: ../../../src/pip/_vendor/README.rst
